package gr.panteion.cmc.newsnotifier

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.IOException

/**
 * Downloads a cmc.panteion.gr listing page and extracts the individual
 * announcement / article links from it.
 *
 * The site (Joomla + Helix Ultimate template) does not expose an RSS feed,
 * so we scrape the rendered HTML instead. Two page layouts are handled:
 *  - "Ανακοινώσεις" category pages: a table of titles + dates
 *  - "Νέα" blog page: cards with an <h2><a>title</a></h2>
 *
 * Rather than hard-coding brittle CSS classes from the current template,
 * we scope the search to the main content region when possible and then
 * keep any link whose href falls under the section's own path — this is
 * resilient to template tweaks and to the two different layouts above.
 */
object NewsScraper {

    private val PAGINATION_WORDS = setOf(
        "Επόμενο", "Προηγούμενο", "Έναρξη", "Τέλος", "Next", "Prev", "Previous", "Start", "End"
    )

    // Region selectors tried in order; first one that yields any candidate
    // links wins. "#sp-component" is the Helix Ultimate component wrapper
    // that holds the actual page content (menus/sidebars live outside it).
    private val CONTENT_SELECTORS = listOf(
        "#sp-component",
        "main",
        "article",
        "body"
    )

    @Throws(IOException::class)
    fun fetchLatest(source: NewsSource, maxItems: Int = 40): List<NewsItem> {
        val doc: Document = Jsoup.connect(source.pageUrl)
            .userAgent("Mozilla/5.0 (Android) CMCNewsNotifier/1.0")
            .timeout(20_000)
            .get()

        val container: Element = CONTENT_SELECTORS
            .asSequence()
            .mapNotNull { doc.selectFirst(it) }
            .firstOrNull { region ->
                region.select("a[href]").any { looksLikeContentLink(it, source) }
            } ?: doc

        val now = System.currentTimeMillis()
        val seenUrls = LinkedHashSet<String>()
        val results = mutableListOf<NewsItem>()

        for (a in container.select("a[href]")) {
            if (!looksLikeContentLink(a, source)) continue
            val absUrl = a.absUrl("href").substringBefore("#")
            if (absUrl.isBlank() || !seenUrls.add(absUrl)) continue

            val title = a.text().trim()
            if (title.isBlank()) continue
            results.add(NewsItem(title = title, url = absUrl, sourceLabel = source.label, firstSeenAt = now))
            if (results.size >= maxItems) break
        }
        return results
    }

    private fun looksLikeContentLink(a: Element, source: NewsSource): Boolean {
        val href = a.attr("href")
        if (href.isBlank() || href.startsWith("#") || href.startsWith("javascript:")) return false

        val text = a.text().trim()
        if (text.length < 8) return false
        if (text in PAGINATION_WORDS) return false
        if (text.all { it.isDigit() }) return false // page-number links like "2", "3"

        val absUrl = a.absUrl("href")
        val path = try {
            java.net.URI(absUrl).path ?: ""
        } catch (e: Exception) {
            return false
        }
        // must sit under this source's own section, and not just be the
        // section root itself (e.g. the nav menu link back to the listing)
        return path.startsWith(source.pathPrefix) && path.trimEnd('/') != source.pathPrefix.trimEnd('/')
    }
}
