package gr.panteion.cmc.newsnotifier

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class NewsAdapter(
    private var items: List<NewsItem>,
    private val onItemClick: (NewsItem) -> Unit
) : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    fun submitList(newItems: List<NewsItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent, false)
        return NewsViewHolder(view)
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        holder.bind(items[position], onItemClick)
    }

    override fun getItemCount(): Int = items.size

    class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title: TextView = itemView.findViewById(R.id.textTitle)
        private val source: TextView = itemView.findViewById(R.id.textSource)
        private val date: TextView = itemView.findViewById(R.id.textDate)
        // Date-only, Greek month names, regardless of the device's own
        // locale — e.g. "25 Σεπτεμβρίου 2026" — matching what's shown on
        // cmc.panteion.gr itself.
        private val dateFormat = DateFormat.getDateInstance(DateFormat.LONG, Locale("el", "GR"))

        fun bind(item: NewsItem, onItemClick: (NewsItem) -> Unit) {
            title.text = item.title
            source.text = item.sourceLabel
            date.text = if (item.publishedAt > 0) dateFormat.format(Date(item.publishedAt)) else ""
            itemView.setOnClickListener { onItemClick(item) }
        }
    }
}
