package gr.panteion.cmc.newsnotifier

import org.json.JSONObject

/**
 * A single announcement / news post found on cmc.panteion.gr.
 *
 * [firstSeenAt] is purely internal bookkeeping (when our app noticed the
 * item), used to tell "new since last check" apart. [publishedAt] is what
 * gets shown/sorted by: the real publish date parsed from the site when
 * available, or a best-effort approximation otherwise (see NewsScraper).
 */
data class NewsItem(
    val title: String,
    val url: String,
    val sourceLabel: String,
    val firstSeenAt: Long,
    val publishedAt: Long = firstSeenAt
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("title", title)
        put("url", url)
        put("sourceLabel", sourceLabel)
        put("firstSeenAt", firstSeenAt)
        put("publishedAt", publishedAt)
    }

    companion object {
        fun fromJson(o: JSONObject): NewsItem {
            val firstSeenAt = o.optLong("firstSeenAt", 0L)
            return NewsItem(
                title = o.getString("title"),
                url = o.getString("url"),
                sourceLabel = o.optString("sourceLabel", ""),
                firstSeenAt = firstSeenAt,
                publishedAt = o.optLong("publishedAt", firstSeenAt)
            )
        }
    }
}

/**
 * One of the monitored listing pages on cmc.panteion.gr.
 */
data class NewsSource(
    val label: String,
    val pageUrl: String,
    /** Only links whose href starts with this path are considered real content links. */
    val pathPrefix: String
)

object NewsSources {
    val ALL = listOf(
        NewsSource(
            label = "Ανακοινώσεις Προπτυχιακού",
            pageUrl = "https://cmc.panteion.gr/news-and-announcements/proptyxiakoy",
            pathPrefix = "/news-and-announcements/proptyxiakoy/"
        ),
        NewsSource(
            label = "Ανακοινώσεις Μεταπτυχιακού",
            pageUrl = "https://cmc.panteion.gr/news-and-announcements/metaptyxiakoy",
            pathPrefix = "/news-and-announcements/metaptyxiakoy/"
        ),
        NewsSource(
            label = "Νέα του Τμήματος",
            pageUrl = "https://cmc.panteion.gr/nea",
            pathPrefix = "/nea/"
        )
    )
}
