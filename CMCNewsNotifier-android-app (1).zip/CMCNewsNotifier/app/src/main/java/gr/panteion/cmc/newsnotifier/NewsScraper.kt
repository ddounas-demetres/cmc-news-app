package gr.panteion.cmc.newsnotifier

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.IOException
import java.util.Calendar
import java.util.regex.Pattern

/**
 * Downloads a cmc.panteion.gr listing page and extracts the individual
 * announcement / article links from it — plus, where available, each
 * item's real publish date.
 *
 * The site (Joomla + Helix Ultimate template) does not expose an RSS feed,
 * so we scrape the rendered HTML instead. Two page layouts are handled:
 *
 *  - "Ανακοινώσεις" category pages (Προπτυχιακού, Μεταπτυχιακού): a table
 *    with columns Τίτλος / Ημερομηνία Δημοσίευσης / Εμφανίσεις. We parse
 *    the real Greek-language date from this table.
 *  - "Νέα" blog page: cards with an <h2><a>title</a></h2> and no visible
 *    per-item publish date anywhere in the listing. For this layout we
 *    fall back to an approximate ordering based on the page's own
 *    (newest-first) display order — there is no real date to read here.
 */
object NewsScraper {

    private val PAGINATION_WORDS = setOf(
        "Επόμενο", "Προηγούμενο", "Έναρξη", "Τέλος", "Next", "Prev", "Previous", "Start", "End"
    )

    // Region selectors tried in order; first one that yields any candidate
    // links wins. "#sp-component" is the Helix Ultimate component wrapper
    // that holds the actual page content (menus/sidebars live outside it).
    private val CONTENT_SELECTORS = listOf(
        "#sp-component",
        "main",
        "article",
        "body"
    )

    // Matches Greek listing dates like "25 Σεπτεμβρίου 2026".
    private val DATE_PATTERN = Pattern.compile("(\\d{1,2})\\s+(\\p{L}+)\\s+(\\d{4})")

    private val GREEK_MONTHS: Map<String, Int> = mapOf(
        "ιανουαριου" to 1, "ιανουαριος" to 1,
        "φεβρουαριου" to 2, "φεβρουαριος" to 2,
        "μαρτιου" to 3, "μαρτιος" to 3,
        "απριλιου" to 4, "απριλιος" to 4,
        "μαιου" to 5, "μαιος" to 5,
        "ιουνιου" to 6, "ιουνιος" to 6,
        "ιουλιου" to 7, "ιουλιος" to 7,
        "αυγουστου" to 8, "αυγουστος" to 8,
        "σεπτεμβριου" to 9, "σεπτεμβριος" to 9,
        "οκτωβριου" to 10, "οκτωβριος" to 10,
        "νοεμβριου" to 11, "νοεμβριος" to 11,
        "δεκεμβριου" to 12, "δεκεμβριος" to 12
    )

    @Throws(IOException::class)
    fun fetchLatest(source: NewsSource, maxItems: Int = 15): List<NewsItem> {
        val doc: Document = Jsoup.connect(source.pageUrl)
            .userAgent("Mozilla/5.0 (Android) CMCNewsNotifier/1.0")
            .timeout(20_000)
            .get()

        val container: Element = CONTENT_SELECTORS
            .asSequence()
            .mapNotNull { doc.selectFirst(it) }
            .firstOrNull { region ->
                region.select("a[href]").any { looksLikeContentLink(it, source) }
            } ?: doc

        val now = System.currentTimeMillis()
        val seenUrls = LinkedHashSet<String>()
        val results = mutableListOf<NewsItem>()

        // --- Layout 1: table-based category list (has real dates) ---
        val table = container.selectFirst("table")
        if (table != null) {
            for (row in table.select("tr")) {
                val cells = row.select("> td")
                if (cells.isEmpty()) continue // header row (uses <th>)

                val anchor = cells.firstNotNullOfOrNull { it.selectFirst("a[href]") } ?: continue
                if (!looksLikeContentLink(anchor, source)) continue

                val absUrl = anchor.absUrl("href").substringBefore("#")
                if (absUrl.isBlank() || !seenUrls.add(absUrl)) continue

                val title = anchor.text().trim()
                if (title.isBlank()) continue

                val publishedAt = cells.firstNotNullOfOrNull { parseGreekDateFromText(it.text()) }

                results.add(
                    NewsItem(
                        title = title,
                        url = absUrl,
                        sourceLabel = source.label,
                        firstSeenAt = now,
                        publishedAt = publishedAt ?: now
                    )
                )
                if (results.size >= maxItems) break
            }
        }

        // --- Layout 2: blog-style cards, no table / no dates found ---
        // (either there was no table at all, e.g. "Νέα", or it didn't
        // contain any of our announcement links)
        if (results.isEmpty()) {
            var position = 0
            for (a in container.select("a[href]")) {
                if (!looksLikeContentLink(a, source)) continue
                val absUrl = a.absUrl("href").substringBefore("#")
                if (absUrl.isBlank() || !seenUrls.add(absUrl)) continue

                val title = a.text().trim()
                if (title.isBlank()) continue

                // No real publish date available on this layout. Stagger
                // synthetic timestamps by the page's own display order
                // (newest-first) so items don't all collapse onto one
                // identical instant when sorted chronologically.
                val approxPublishedAt = now - position * 60_000L
                position++

                results.add(
                    NewsItem(
                        title = title,
                        url = absUrl,
                        sourceLabel = source.label,
                        firstSeenAt = now,
                        publishedAt = approxPublishedAt
                    )
                )
                if (results.size >= maxItems) break
            }
        }

        return results
    }

    private fun parseGreekDateFromText(text: String): Long? {
        val matcher = DATE_PATTERN.matcher(text)
        if (!matcher.find()) return null
        val day = matcher.group(1)?.toIntOrNull() ?: return null
        val monthToken = matcher.group(2) ?: return null
        val year = matcher.group(3)?.toIntOrNull() ?: return null

        val normalizedMonth = stripGreekAccents(monthToken.lowercase())
        val month = GREEK_MONTHS[normalizedMonth] ?: return null

        return try {
            val cal = Calendar.getInstance()
            cal.clear()
            cal.set(year, month - 1, day, 12, 0, 0)
            cal.timeInMillis
        } catch (e: Exception) {
            null
        }
    }

    private fun stripGreekAccents(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in input) {
            sb.append(
                when (c) {
                    'ά' -> 'α'
                    'έ' -> 'ε'
                    'ή' -> 'η'
                    'ί', 'ϊ', 'ΐ' -> 'ι'
                    'ό' -> 'ο'
                    'ύ', 'ϋ', 'ΰ' -> 'υ'
                    'ώ' -> 'ω'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    private fun looksLikeContentLink(a: Element, source: NewsSource): Boolean {
        val href = a.attr("href")
        if (href.isBlank() || href.startsWith("#") || href.startsWith("javascript:")) return false

        val text = a.text().trim()
        if (text.length < 8) return false
        if (text in PAGINATION_WORDS) return false
        if (text.all { it.isDigit() }) return false // page-number links like "2", "3"

        val absUrl = a.absUrl("href")
        val path = try {
            java.net.URI(absUrl).path ?: ""
        } catch (e: Exception) {
            return false
        }
        // must sit under this source's own section, and not just be the
        // section root itself (e.g. the nav menu link back to the listing)
        return path.startsWith(source.pathPrefix) && path.trimEnd('/') != source.pathPrefix.trimEnd('/')
    }
}
