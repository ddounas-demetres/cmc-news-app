package gr.panteion.cmc.newsnotifier

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CheckNewsWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val repo = NewsRepository(applicationContext)
            if (repo.isFirstRunEver()) {
                // Don't spam the user with the entire historical archive
                // the first time the app ever runs.
                repo.baselineWithoutNotifying()
                return@withContext Result.success()
            }

            val newItems = repo.checkForUpdates()
            if (newItems.isNotEmpty()) {
                NotificationHelper.notifyNewItems(applicationContext, newItems)
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val UNIQUE_WORK_NAME = "cmc_news_periodic_check"
        const val ONE_OFF_WORK_NAME = "cmc_news_manual_check"
    }
}
