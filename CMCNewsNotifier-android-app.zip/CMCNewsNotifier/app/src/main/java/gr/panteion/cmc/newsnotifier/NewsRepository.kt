package gr.panteion.cmc.newsnotifier

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Stores every item we've ever seen (so we know what's "new" on the next
 * check) and exposes the merged, sorted list for display in the app.
 */
class NewsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val lock = ReentrantLock()

    /** All items known so far, grouped by category in the app's fixed
     *  category order (see NewsSources.ALL), newest first within each
     *  category. */
    fun getAllStored(): List<NewsItem> = lock.withLock {
        val categoryOrder = NewsSources.ALL.mapIndexed { index, source -> source.label to index }.toMap()
        readAll().sortedWith(
            compareBy<NewsItem> { categoryOrder[it.sourceLabel] ?: Int.MAX_VALUE }
                .thenByDescending { it.firstSeenAt }
        )
    }

    /**
     * Fetches every configured source, compares against what's already
     * stored, persists the union, and returns only the items that are
     * genuinely new (so the caller can notify about them).
     */
    fun checkForUpdates(): List<NewsItem> = lock.withLock {
        val existing = readAll()
        val existingUrls = existing.map { it.url }.toHashSet()

        val freshlyFound = mutableListOf<NewsItem>()
        for (source in NewsSources.ALL) {
            try {
                freshlyFound += NewsScraper.fetchLatest(source)
            } catch (e: Exception) {
                // Network hiccup on one source shouldn't block the others.
            }
        }

        val genuinelyNew = freshlyFound.filter { it.url !in existingUrls }
        // De-dupe within this batch too (same URL could appear from
        // overlapping nav + content matches).
        val newDeduped = LinkedHashMap<String, NewsItem>()
        genuinelyNew.forEach { newDeduped.putIfAbsent(it.url, it) }

        if (newDeduped.isNotEmpty()) {
            val merged = existing + newDeduped.values
            writeAll(merged)
        }
        return newDeduped.values.toList()
    }

    fun isFirstRunEver(): Boolean = lock.withLock { readAll().isEmpty() }

    /**
     * Used on the very first launch: silently records the current state of
     * the site as "already seen" so the user doesn't get flooded with
     * notifications for dozens of historical posts.
     */
    fun baselineWithoutNotifying() = lock.withLock {
        val found = mutableListOf<NewsItem>()
        for (source in NewsSources.ALL) {
            try {
                found += NewsScraper.fetchLatest(source)
            } catch (e: Exception) {
                // ignore, will just try again on next scheduled check
            }
        }
        writeAll(found)
    }

    private fun readAll(): List<NewsItem> {
        val raw = prefs.getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { NewsItem.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeAll(items: List<NewsItem>) {
        // Keep the store from growing forever.
        val trimmed = items.sortedByDescending { it.firstSeenAt }.take(MAX_STORED)
        val arr = JSONArray()
        trimmed.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "cmc_news_prefs"
        private const val KEY_ITEMS = "seen_items"
        private const val MAX_STORED = 300
    }
}
