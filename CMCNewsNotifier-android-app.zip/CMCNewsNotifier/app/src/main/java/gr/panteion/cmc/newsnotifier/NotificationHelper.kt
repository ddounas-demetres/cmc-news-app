package gr.panteion.cmc.newsnotifier

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {

    private const val CHANNEL_ID = "cmc_news_channel"
    private const val GROUP_KEY = "gr.panteion.cmc.newsnotifier.NEWS_GROUP"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    context.getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = context.getString(R.string.notification_channel_description)
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    /**
     * Shows one notification per new item (Android automatically bundles
     * them under a summary when there are several), each opening the
     * article directly in the browser when tapped.
     */
    fun notifyNewItems(context: Context, items: List<NewsItem>) {
        ensureChannel(context)
        val manager = NotificationManagerCompat.from(context)

        items.forEachIndexed { index, item ->
            val openIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
            val pendingIntent = PendingIntent.getActivity(
                context,
                item.url.hashCode(),
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(item.sourceLabel)
                .setContentText(item.title)
                .setStyle(NotificationCompat.BigTextStyle().bigText(item.title))
                .setGroup(GROUP_KEY)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()

            if (hasPostPermission(context)) {
                manager.notify(BASE_NOTIFICATION_ID + index, notification)
            }
        }

        if (items.size > 1) {
            val summary = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(context.getString(R.string.app_name))
                .setContentText(context.getString(R.string.new_posts_summary, items.size))
                .setStyle(
                    NotificationCompat.InboxStyle().also { style ->
                        items.take(5).forEach { style.addLine(it.title) }
                    }
                )
                .setGroup(GROUP_KEY)
                .setGroupSummary(true)
                .setAutoCancel(true)
                .build()
            if (hasPostPermission(context)) {
                manager.notify(SUMMARY_NOTIFICATION_ID, summary)
            }
        }
    }

    private fun hasPostPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.POST_NOTIFICATIONS
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private const val BASE_NOTIFICATION_ID = 1000
    private const val SUMMARY_NOTIFICATION_ID = 999
}
