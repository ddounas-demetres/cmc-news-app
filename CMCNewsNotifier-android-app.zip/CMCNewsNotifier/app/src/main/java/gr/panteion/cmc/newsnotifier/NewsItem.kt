package gr.panteion.cmc.newsnotifier

import org.json.JSONObject

/**
 * A single announcement / news post found on cmc.panteion.gr.
 */
data class NewsItem(
    val title: String,
    val url: String,
    val sourceLabel: String,
    val firstSeenAt: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("title", title)
        put("url", url)
        put("sourceLabel", sourceLabel)
        put("firstSeenAt", firstSeenAt)
    }

    companion object {
        fun fromJson(o: JSONObject): NewsItem = NewsItem(
            title = o.getString("title"),
            url = o.getString("url"),
            sourceLabel = o.optString("sourceLabel", ""),
            firstSeenAt = o.optLong("firstSeenAt", 0L)
        )
    }
}

/**
 * One of the monitored listing pages on cmc.panteion.gr.
 */
data class NewsSource(
    val label: String,
    val pageUrl: String,
    /** Only links whose href starts with this path are considered real content links. */
    val pathPrefix: String
)

object NewsSources {
    val ALL = listOf(
        NewsSource(
            label = "Ανακοινώσεις Προπτυχιακού",
            pageUrl = "https://cmc.panteion.gr/news-and-announcements/proptyxiakoy",
            pathPrefix = "/news-and-announcements/proptyxiakoy/"
        ),
        NewsSource(
            label = "Ανακοινώσεις Μεταπτυχιακού",
            pageUrl = "https://cmc.panteion.gr/news-and-announcements/metaptyxiakoy",
            pathPrefix = "/news-and-announcements/metaptyxiakoy/"
        ),
        NewsSource(
            label = "Νέα του Τμήματος",
            pageUrl = "https://cmc.panteion.gr/nea",
            pathPrefix = "/nea/"
        )
    )
}
