package gr.panteion.cmc.newsnotifier

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            NewsNotifierApp.schedulePeriodicCheck(
                context,
                SettingsStore.getInterval(context),
                replace = false
            )
        }
    }
}
