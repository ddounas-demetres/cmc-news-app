package gr.panteion.cmc.newsnotifier

import android.content.Context

/**
 * The interval choices offered to the user. WorkManager's practical minimum
 * for periodic work is 15 minutes, so we don't go below 1 hour here to keep
 * battery impact sensible for a background poller.
 */
enum class CheckInterval(val hours: Long, val displayLabel: String) {
    ONE_HOUR(1, "Κάθε ώρα"),
    THREE_HOURS(3, "Κάθε 3 ώρες"),
    SIX_HOURS(6, "Κάθε 6 ώρες"),
    TWELVE_HOURS(12, "Κάθε 12 ώρες"),
    DAILY(24, "Μία φορά την ημέρα");

    companion object {
        fun fromHours(hours: Long): CheckInterval =
            values().firstOrNull { it.hours == hours } ?: SIX_HOURS
    }
}

object SettingsStore {
    private const val PREFS_NAME = "cmc_news_settings"
    private const val KEY_INTERVAL_HOURS = "interval_hours"

    fun getInterval(context: Context): CheckInterval {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return CheckInterval.fromHours(prefs.getLong(KEY_INTERVAL_HOURS, CheckInterval.SIX_HOURS.hours))
    }

    fun setInterval(context: Context, interval: CheckInterval) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putLong(KEY_INTERVAL_HOURS, interval.hours).apply()
    }
}
