package gr.panteion.cmc.newsnotifier

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var repository: NewsRepository
    private lateinit var adapter: NewsAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyView: android.widget.TextView

    private val notificationPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = NewsRepository(this)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        swipeRefresh = findViewById(R.id.swipeRefresh)
        emptyView = findViewById(R.id.textEmpty)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = NewsAdapter(emptyList()) { item ->
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.url)))
        }
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { runManualCheck() }

        val fab = findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.fab)
        fab.setOnClickListener { runManualCheck() }

        requestNotificationPermissionIfNeeded()
        loadStoredItems()

        // Kick off a first check right away so the list isn't empty on
        // a brand-new install.
        runManualCheck()
    }

    override fun onResume() {
        super.onResume()
        loadStoredItems()
    }

    private fun loadStoredItems() {
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { repository.getAllStored() }
            adapter.submitList(items)
            emptyView.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun runManualCheck() {
        swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val wasFirstRun = withContext(Dispatchers.IO) { repository.isFirstRunEver() }
            val newItems = withContext(Dispatchers.IO) {
                if (wasFirstRun) {
                    repository.baselineWithoutNotifying()
                    emptyList()
                } else {
                    repository.checkForUpdates()
                }
            }
            if (newItems.isNotEmpty()) {
                NotificationHelper.notifyNewItems(this@MainActivity, newItems)
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.new_posts_summary, newItems.size),
                    Toast.LENGTH_SHORT
                ).show()
            }
            loadStoredItems()
            swipeRefresh.isRefreshing = false
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            showIntervalDialog()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showIntervalDialog() {
        val options = CheckInterval.values()
        val labels = options.map { it.displayLabel }.toTypedArray()
        val current = SettingsStore.getInterval(this)
        val currentIndex = options.indexOf(current)

        AlertDialog.Builder(this)
            .setTitle(R.string.settings_interval_title)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val chosen = options[which]
                SettingsStore.setInterval(this, chosen)
                NewsNotifierApp.schedulePeriodicCheck(this, chosen, replace = true)
                Toast.makeText(this, chosen.displayLabel, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
