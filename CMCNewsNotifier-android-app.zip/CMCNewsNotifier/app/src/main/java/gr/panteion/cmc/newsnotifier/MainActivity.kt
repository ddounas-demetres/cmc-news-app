package gr.panteion.cmc.newsnotifier

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var repository: NewsRepository
    private lateinit var adapter: NewsAdapter
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var emptyView: android.widget.TextView
    private lateinit var tabLayout: TabLayout

    private var allItems: List<NewsItem> = emptyList()
    // Which category tab is active. Defaults to 0 (Προπτυχιακού) so the
    // app opens on that category; tapping the active tab again clears
    // this back to null (unified, mixed-category view).
    private var selectedCategoryIndex: Int? = 0

    // One background per tab position; cycles if there are ever more
    // categories than colors defined here.
    private val tabBackgrounds = listOf(R.drawable.tab_bg_0, R.drawable.tab_bg_1, R.drawable.tab_bg_2)

    private val notificationPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        repository = NewsRepository(this)

        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        tabLayout = findViewById(R.id.tabLayout)
        setupTabs()

        swipeRefresh = findViewById(R.id.swipeRefresh)
        emptyView = findViewById(R.id.textEmpty)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = NewsAdapter(emptyList()) { item ->
            openArticle(item)
        }
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { runManualCheck() }

        val fab = findViewById<com.google.android.material.floatingactionbutton.FloatingActionButton>(R.id.fab)
        fab.setOnClickListener { runManualCheck() }

        requestNotificationPermissionIfNeeded()
        loadStoredItems()

        // Kick off a first check right away so the list isn't empty on
        // a brand-new install.
        runManualCheck()
    }

    private fun setupTabs() {
        tabLayout.removeAllTabs()
        NewsSources.ALL.forEachIndexed { index, source ->
            val tab = tabLayout.newTab()
            val customView = LayoutInflater.from(this).inflate(R.layout.tab_item, tabLayout, false)
            val label = customView.findViewById<TextView>(R.id.tabLabel)
            label.text = source.label
            label.setBackgroundResource(tabBackgrounds[index % tabBackgrounds.size])
            label.alpha = if (index == selectedCategoryIndex) 1.0f else 0.55f
            tab.customView = customView
            // The default tab (index 0, Προπτυχιακού) starts selected so
            // the app opens on that category rather than the unified view.
            tabLayout.addTab(tab, index == selectedCategoryIndex)
        }

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                tab.customView?.findViewById<TextView>(R.id.tabLabel)?.alpha = 1.0f
                selectedCategoryIndex = tab.position
                applyFilter()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {
                tab.customView?.findViewById<TextView>(R.id.tabLabel)?.alpha = 0.55f
            }

            override fun onTabReselected(tab: TabLayout.Tab) {
                // Tapping the already-active tab again turns the filter
                // off and returns to the unified, mixed-category view.
                tab.customView?.findViewById<TextView>(R.id.tabLabel)?.alpha = 0.55f
                selectedCategoryIndex = null
                applyFilter()
            }
        })
    }

    private fun openArticle(item: NewsItem) {
        if (item.url.isBlank()) {
            Toast.makeText(this, "Μη έγκυρος σύνδεσμος για αυτή την ανάρτηση.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = Uri.parse(item.url)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            // Not pre-checking with resolveActivity(): on Android 11+ it
            // unreliably reports "no app found" for other apps' intents
            // unless a matching <queries> manifest entry is declared,
            // even when a browser is genuinely installed. Just try to
            // start it directly and only report a problem if it actually
            // fails.
            startActivity(intent)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "Δεν βρέθηκε browser για να ανοίξει ο σύνδεσμος.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Δεν ήταν δυνατό το άνοιγμα: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        loadStoredItems()
    }

    private fun loadStoredItems() {
        lifecycleScope.launch {
            allItems = withContext(Dispatchers.IO) { repository.getAllStored() }
            applyFilter()
        }
    }

    private fun applyFilter() {
        val currentIndex = selectedCategoryIndex
        val filtered = if (currentIndex == null) {
            // No category selected → everything mixed together, newest first.
            allItems.sortedByDescending { it.publishedAt }
        } else {
            val currentLabel = NewsSources.ALL.getOrNull(currentIndex)?.label
            allItems.filter { it.sourceLabel == currentLabel }
        }
        adapter.submitList(filtered)
        emptyView.visibility = if (filtered.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun runManualCheck() {
        swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val wasFirstRun = withContext(Dispatchers.IO) { repository.isFirstRunEver() }
            val newItems = withContext(Dispatchers.IO) {
                if (wasFirstRun) {
                    repository.baselineWithoutNotifying()
                    emptyList()
                } else {
                    repository.checkForUpdates()
                }
            }
            if (newItems.isNotEmpty()) {
                NotificationHelper.notifyNewItems(this@MainActivity, newItems)
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.new_posts_summary, newItems.size),
                    Toast.LENGTH_SHORT
                ).show()
            }
            loadStoredItems()
            swipeRefresh.isRefreshing = false
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            showIntervalDialog()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showIntervalDialog() {
        val options = CheckInterval.values()
        val labels = options.map { it.displayLabel }.toTypedArray()
        val current = SettingsStore.getInterval(this)
        val currentIndex = options.indexOf(current)

        AlertDialog.Builder(this)
            .setTitle(R.string.settings_interval_title)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                val chosen = options[which]
                SettingsStore.setInterval(this, chosen)
                NewsNotifierApp.schedulePeriodicCheck(this, chosen, replace = true)
                Toast.makeText(this, chosen.displayLabel, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
